from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import Callable, TypeVar

SCHEMA = '''
CREATE TABLE IF NOT EXISTS checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    available INTEGER NOT NULL,
    status TEXT NOT NULL,
    error TEXT,
    created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS found_usernames (
    username TEXT PRIMARY KEY,
    first_seen_at INTEGER NOT NULL,
    last_seen_at INTEGER NOT NULL,
    length INTEGER NOT NULL,
    has_digits INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS search_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    target_count INTEGER NOT NULL,
    generated_count INTEGER NOT NULL,
    checked_count INTEGER NOT NULL,
    found_count INTEGER NOT NULL,
    length INTEGER NOT NULL,
    digits INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);

-- Table of banned user IDs.  When a user_id is present in this table,
-- the bot will simulate a search but never return results.  Admins
-- manage this list via the WebApp.  The primary key prevents
-- duplicates and makes lookup efficient.
CREATE TABLE IF NOT EXISTS banned_users (
    user_id INTEGER PRIMARY KEY,
    created_at INTEGER NOT NULL
);
'''

T = TypeVar('T')


def connect(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=NORMAL')
    con.execute('PRAGMA busy_timeout=30000')
    con.execute('PRAGMA temp_store=MEMORY')
    return con


def _retry(fn: Callable[[], T], attempts: int = 6, delay: float = 0.18) -> T:
    last_error: Exception | None = None
    for i in range(attempts):
        try:
            return fn()
        except sqlite3.OperationalError as e:
            last_error = e
            if 'locked' not in str(e).lower() and 'busy' not in str(e).lower():
                raise
            time.sleep(delay * (i + 1))
    if last_error:
        raise last_error
    raise RuntimeError('sqlite retry failed')


def init_db(path: Path) -> None:
    def work() -> None:
        with connect(path) as con:
            # Execute the schema which now includes the banned_users table.
            con.executescript(SCHEMA)
            con.commit()
    _retry(work)


def log_check(path: Path, username: str, available: bool, status: str, error: str | None = None) -> None:
    now = int(time.time())

    def work() -> None:
        with connect(path) as con:
            con.execute('BEGIN IMMEDIATE')
            con.execute(
                'INSERT INTO checks(username, available, status, error, created_at) VALUES(?, ?, ?, ?, ?)',
                (username, int(available), status, error, now),
            )
            if available:
                con.execute(
                    '''INSERT INTO found_usernames(username, first_seen_at, last_seen_at, length, has_digits)
                       VALUES(?, ?, ?, ?, ?)
                       ON CONFLICT(username) DO UPDATE SET last_seen_at=excluded.last_seen_at''',
                    (username, now, now, len(username), int(any(ch.isdigit() for ch in username))),
                )
            con.commit()
    _retry(work)


def log_search_run(
    path: Path,
    user_id: int,
    target_count: int,
    generated_count: int,
    checked_count: int,
    found_count: int,
    length: int,
    digits: bool,
) -> None:
    def work() -> None:
        with connect(path) as con:
            con.execute('BEGIN IMMEDIATE')
            con.execute(
                '''INSERT INTO search_runs(user_id, target_count, generated_count, checked_count, found_count, length, digits, created_at)
                   VALUES(?, ?, ?, ?, ?, ?, ?, ?)''',
                (user_id, target_count, generated_count, checked_count, found_count, length, int(digits), int(time.time())),
            )
            con.commit()
    _retry(work)


def get_recent_found(path: Path, limit: int = 30) -> list[str]:
    def work() -> list[str]:
        with connect(path) as con:
            rows = con.execute(
                'SELECT username FROM found_usernames ORDER BY last_seen_at DESC LIMIT ?',
                (limit,),
            ).fetchall()
        return [row['username'] for row in rows]
    return _retry(work)


def get_stats(path: Path) -> dict[str, int]:
    def work() -> dict[str, int]:
        with connect(path) as con:
            checks = con.execute('SELECT COUNT(*) AS c FROM checks').fetchone()['c']
            found = con.execute('SELECT COUNT(*) AS c FROM found_usernames').fetchone()['c']
            runs = con.execute('SELECT COUNT(*) AS c FROM search_runs').fetchone()['c']
            today = int(time.time()) - 86400
            checks_today = con.execute('SELECT COUNT(*) AS c FROM checks WHERE created_at >= ?', (today,)).fetchone()['c']
            found_today = con.execute('SELECT COUNT(*) AS c FROM found_usernames WHERE last_seen_at >= ?', (today,)).fetchone()['c']
        return {
            'checks': checks,
            'found': found,
            'runs': runs,
            'checks_today': checks_today,
            'found_today': found_today,
        }
    return _retry(work)

# ---------------------------------------------------------------------------
# Ban management helpers
#
# The admin can add or remove user IDs from the banned_users table.  When a
# banned user attempts to perform a username search, the bot will fake a
# search and return no results.  These helpers encapsulate the SQLite
# operations and perform simple error handling.

def add_banned_user(path: Path, user_id: int) -> None:
    """Insert a user_id into the banned list.  Duplicate inserts are ignored."""
    now = int(time.time())

    def work() -> None:
        with connect(path) as con:
            con.execute('BEGIN IMMEDIATE')
            con.execute('INSERT OR IGNORE INTO banned_users(user_id, created_at) VALUES(?, ?)', (int(user_id), now))
            con.commit()
    _retry(work)


def remove_banned_user(path: Path, user_id: int) -> None:
    """Remove a user_id from the banned list if it exists."""

    def work() -> None:
        with connect(path) as con:
            con.execute('BEGIN IMMEDIATE')
            con.execute('DELETE FROM banned_users WHERE user_id = ?', (int(user_id),))
            con.commit()
    _retry(work)


def list_banned_users(path: Path) -> list[int]:
    """Return a list of all banned user IDs."""

    def work() -> list[int]:
        with connect(path) as con:
            rows = con.execute('SELECT user_id FROM banned_users ORDER BY created_at DESC').fetchall()
        return [int(row['user_id']) for row in rows]
    return _retry(work)


def is_user_banned(path: Path, user_id: int) -> bool:
    """Check whether a given user_id is present in the banned list."""

    def work() -> bool:
        with connect(path) as con:
            row = con.execute('SELECT 1 FROM banned_users WHERE user_id = ? LIMIT 1', (int(user_id),)).fetchone()
        return bool(row)
    return _retry(work)
