from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from telethon import TelegramClient, functions, errors
from telethon.sessions import StringSession

from .config import Settings
from . import db


@dataclass
class CheckResult:
    username: str
    available: bool
    status: str
    error: str | None = None
    wait_seconds: int | None = None


_client_lock = asyncio.Lock()
_check_lock = asyncio.Lock()
_client: TelegramClient | None = None
_LOGIN_STATE: dict[str, Any] = {}


def _load_account(settings: Settings) -> dict[str, Any] | None:
    if settings.telethon_account_json.exists():
        with settings.telethon_account_json.open('r', encoding='utf-8') as f:
            return json.load(f)
    if settings.telethon_api_id and settings.telethon_api_hash:
        return {
            'api_id': int(settings.telethon_api_id),
            'api_hash': settings.telethon_api_hash,
        }
    return None


def _save_account(settings: Settings, api_id: int, api_hash: str) -> None:
    settings.telethon_account_json.parent.mkdir(parents=True, exist_ok=True)
    data = {'api_id': int(api_id), 'api_hash': api_hash}
    with settings.telethon_account_json.open('w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.chmod(settings.telethon_account_json, 0o600)


def _load_string_session(settings: Settings) -> str | None:
    if settings.telethon_string_session_path.exists():
        value = settings.telethon_string_session_path.read_text(encoding='utf-8').strip()
        return value or None
    return None


def _save_string_session(settings: Settings, session_string: str) -> None:
    settings.telethon_string_session_path.parent.mkdir(parents=True, exist_ok=True)
    if settings.telethon_string_session_path.exists():
        shutil.copy2(settings.telethon_string_session_path, settings.telethon_string_session_path.with_suffix('.string.bak'))
    settings.telethon_string_session_path.write_text(session_string.strip() + '\n', encoding='utf-8')
    os.chmod(settings.telethon_string_session_path, 0o600)


def _looks_like_phone(phone: str) -> bool:
    phone = phone.strip().replace(' ', '')
    return bool(re.fullmatch(r'\+[1-9]\d{7,14}', phone))


def session_exists(settings: Settings) -> bool:
    return bool(_load_string_session(settings)) or settings.telethon_session_path.exists()


async def _legacy_sqlite_client(settings: Settings, account: dict[str, Any]) -> TelegramClient | None:
    if not settings.telethon_session_path.exists():
        return None
    client = TelegramClient(str(settings.telethon_session_path), int(account['api_id']), account['api_hash'])
    await client.connect()
    return client


async def _make_client(settings: Settings, account: dict[str, Any]) -> TelegramClient:
    session_string = _load_string_session(settings)
    if session_string:
        return TelegramClient(StringSession(session_string), int(account['api_id']), account['api_hash'])

    legacy = await _legacy_sqlite_client(settings, account)
    if legacy:
        if await legacy.is_user_authorized():
            _save_string_session(settings, legacy.session.save())
        return legacy

    raise RuntimeError('Telethon session is missing')


async def get_status(settings: Settings) -> dict[str, Any]:
    account = _load_account(settings)
    status = {
        'session_mode': 'string' if _load_string_session(settings) else ('legacy_sqlite' if settings.telethon_session_path.exists() else 'none'),
        'string_session_file': str(settings.telethon_string_session_path),
        'legacy_session_file': str(settings.telethon_session_path),
        'session_exists': session_exists(settings),
        'account_json_exists': settings.telethon_account_json.exists(),
        'api_configured': bool(account),
        'authorized': False,
        'me': None,
        'error': None,
    }
    if not account or not session_exists(settings):
        return status
    client: TelegramClient | None = None
    try:
        client = await _make_client(settings, account)
        if not client.is_connected():
            await client.connect()
        status['authorized'] = await client.is_user_authorized()
        if status['authorized']:
            me = await client.get_me()
            status['me'] = {
                'id': me.id,
                'username': me.username,
                'first_name': me.first_name,
                'phone': getattr(me, 'phone', None),
            }
    except Exception as e:  # noqa: BLE001
        status['error'] = str(e)
    finally:
        if client and client.is_connected():
            await client.disconnect()
    return status


async def _get_client(settings: Settings) -> TelegramClient:
    global _client
    async with _client_lock:
        account = _load_account(settings)
        if not account:
            raise RuntimeError('Telethon API is not configured')
        if not session_exists(settings):
            raise RuntimeError('Telethon session is missing')
        if _client is None:
            _client = await _make_client(settings, account)
            await _client.connect()
        elif not _client.is_connected():
            await _client.connect()
        if not await _client.is_user_authorized():
            raise RuntimeError('Telethon session is not authorized')
        return _client


async def disconnect_cached_client() -> None:
    global _client
    async with _client_lock:
        if _client:
            await _client.disconnect()
            _client = None


async def check_username(settings: Settings, username: str) -> CheckResult:
    username = username.strip().replace('@', '').lower()
    try:
        async with _check_lock:
            client = await _get_client(settings)
            available = bool(await client(functions.account.CheckUsernameRequest(username=username)))
        result = CheckResult(username=username, available=available, status='ok')
        db.log_check(settings.database_path, username, available, 'ok')
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except errors.FloodWaitError as e:
        result = CheckResult(username=username, available=False, status='flood_wait', error=str(e), wait_seconds=int(e.seconds))
        db.log_check(settings.database_path, username, False, 'flood_wait', str(e))
        return result
    except errors.UsernameInvalidError as e:
        result = CheckResult(username=username, available=False, status='invalid', error=str(e))
        db.log_check(settings.database_path, username, False, 'invalid', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except errors.UsernameOccupiedError as e:
        result = CheckResult(username=username, available=False, status='occupied', error=str(e))
        db.log_check(settings.database_path, username, False, 'occupied', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result
    except Exception as e:  # noqa: BLE001
        result = CheckResult(username=username, available=False, status='error', error=str(e))
        db.log_check(settings.database_path, username, False, 'error', str(e))
        await asyncio.sleep(settings.check_delay_seconds)
        return result


async def check_until_found(
    settings: Settings,
    candidates: list[str],
    target_count: int,
) -> tuple[list[CheckResult], list[CheckResult], int | None]:
    found: list[CheckResult] = []
    checked: list[CheckResult] = []
    flood_wait: int | None = None
    for username in candidates:
        if len(checked) >= settings.max_checks_per_request:
            break
        result = await check_username(settings, username)
        checked.append(result)
        if result.status == 'flood_wait':
            flood_wait = result.wait_seconds
            break
        if result.available:
            found.append(result)
            if len(found) >= target_count:
                break
    return found, checked, flood_wait


async def start_manual_login(settings: Settings, api_id: int, api_hash: str, phone: str) -> dict[str, Any]:
    global _LOGIN_STATE
    phone = phone.strip().replace(' ', '')
    if not _looks_like_phone(phone):
        return {'ok': False, 'step': 'phone', 'error': 'Номер невалидный. Формат: +49123456789'}

    client = TelegramClient(StringSession(), int(api_id), api_hash)
    await client.connect()
    try:
        sent = await client.send_code_request(phone)
        session_string = client.session.save()
    finally:
        await client.disconnect()

    _LOGIN_STATE = {
        'api_id': int(api_id),
        'api_hash': api_hash,
        'phone': phone,
        'phone_code_hash': sent.phone_code_hash,
        'session_string': session_string,
    }
    return {'ok': True, 'step': 'code', 'phone': phone, 'message': 'Код отправлен'}


async def complete_manual_login(settings: Settings, code: str, password: str | None = None) -> dict[str, Any]:
    global _LOGIN_STATE
    if not _LOGIN_STATE:
        return {'ok': False, 'step': 'phone', 'error': 'Сначала запроси код.'}

    if not code.strip():
        return {'ok': False, 'step': 'code', 'error': 'Введи код из Telegram.'}

    client = TelegramClient(StringSession(_LOGIN_STATE['session_string']), int(_LOGIN_STATE['api_id']), _LOGIN_STATE['api_hash'])
    await client.connect()
    try:
        try:
            await client.sign_in(
                phone=_LOGIN_STATE['phone'],
                code=code.strip(),
                phone_code_hash=_LOGIN_STATE['phone_code_hash'],
            )
        except errors.SessionPasswordNeededError:
            if not password:
                session_string = client.session.save()
                _LOGIN_STATE['session_string'] = session_string
                return {'ok': False, 'step': 'password', 'requires_password': True, 'error': 'На аккаунте включен пароль 2FA.'}
            await client.sign_in(password=password)

        me = await client.get_me()
        _save_string_session(settings, client.session.save())
        _save_account(settings, int(_LOGIN_STATE['api_id']), _LOGIN_STATE['api_hash'])
        _LOGIN_STATE = {}
        await disconnect_cached_client()
        return {
            'ok': True,
            'step': 'done',
            'me': {'id': me.id, 'username': me.username, 'first_name': me.first_name},
        }
    except errors.PhoneCodeInvalidError:
        return {'ok': False, 'step': 'code', 'error': 'Код неверный.'}
    except errors.PhoneCodeExpiredError:
        _LOGIN_STATE = {}
        return {'ok': False, 'step': 'phone', 'error': 'Код устарел. Отправь новый код.'}
    except errors.PasswordHashInvalidError:
        return {'ok': False, 'step': 'password', 'requires_password': True, 'error': '2FA пароль неверный.'}
    except Exception as e:  # noqa: BLE001
        return {'ok': False, 'step': 'code', 'error': str(e)}
    finally:
        if client.is_connected():
            await client.disconnect()


async def import_session_file(settings: Settings, api_id: int, api_hash: str, uploaded_path: Path) -> dict[str, Any]:
    client = TelegramClient(str(uploaded_path), int(api_id), api_hash)
    await client.connect()
    try:
        authorized = await client.is_user_authorized()
        if not authorized:
            return {'ok': False, 'error': 'Session imported, but account is not authorized'}
        me = await client.get_me()
        _save_string_session(settings, client.session.save())
        _save_account(settings, api_id, api_hash)
        await disconnect_cached_client()
        return {'ok': True, 'me': {'id': me.id, 'username': me.username, 'first_name': me.first_name}}
    finally:
        if client.is_connected():
            await client.disconnect()
