from __future__ import annotations

import random
import re

VOWELS = 'aeiou'
CONSONANTS = 'bcdfghjklmnprstvwyz'
SOFT_CONSONANTS = 'bcdfgklmnprstvwxyz'
DIGITS = '23456789'

# Буквы q/x оставлены с малым весом через отдельные хвосты не используются.
# Это снижает мусор вроде qxj9z.

PATTERNS_6 = [
    'CVCVCV',  # sayuci, tucupo, zuduzi
    'CVCVCV',
    'CVCVCV',
    'CVCVCV',
    'VCVCVC',
]

PATTERNS_5 = [
    'CVCVC',
    'CVCVC',
    'CVCVC',
    'VCVCV',
]

DIGIT_PATTERNS_6 = [
    'CVCVCN',
    'CVCVCN',
    'CVCVNC',
    'CVNCVC',
]

DIGIT_PATTERNS_5 = [
    'CVCVN',
    'CVCVN',
    'CVNCV',
]

BLOCKED_FRAGMENTS = [
    'xxx', 'sex', 'ass', 'cum', 'fuk', 'fuck', 'nig', 'hitler', 'nazi', 'kkk',
]

USERNAME_RE = re.compile(r'^[a-z][a-z0-9_]{4,31}$')


def _pick(symbol: str) -> str:
    if symbol == 'C':
        return random.choice(CONSONANTS)
    if symbol == 'S':
        return random.choice(SOFT_CONSONANTS)
    if symbol == 'V':
        return random.choice(VOWELS)
    if symbol == 'N':
        return random.choice(DIGITS)
    return symbol.lower()


def _render(pattern: str) -> str:
    return ''.join(_pick(ch) for ch in pattern)


def _is_nice(username: str, length: int, digits: bool) -> bool:
    if len(username) != length:
        return False
    if not USERNAME_RE.match(username):
        return False
    if not digits and any(ch.isdigit() for ch in username):
        return False
    if username[0].isdigit():
        return False
    if '__' in username:
        return False
    if any(fragment in username for fragment in BLOCKED_FRAGMENTS):
        return False
    # Не допускаем 3 одинаковых символа подряд.
    for i in range(len(username) - 2):
        if username[i] == username[i + 1] == username[i + 2]:
            return False
    # Слишком много согласных подряд звучит плохо.
    consonant_run = 0
    for ch in username:
        if ch in CONSONANTS:
            consonant_run += 1
            if consonant_run >= 4:
                return False
        else:
            consonant_run = 0
    return True


def generate_username(length: int = 6, digits: bool = False) -> str:
    if length not in (5, 6):
        raise ValueError('length must be 5 or 6')

    if digits:
        patterns = DIGIT_PATTERNS_6 if length == 6 else DIGIT_PATTERNS_5
    else:
        patterns = PATTERNS_6 if length == 6 else PATTERNS_5

    for _ in range(100):
        username = _render(random.choice(patterns))
        if _is_nice(username, length, digits):
            return username
    raise RuntimeError('failed to generate username')


def generate_usernames(length: int = 6, digits: bool = False, count: int = 100) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    attempts = 0
    while len(result) < count and attempts < count * 20:
        attempts += 1
        username = generate_username(length=length, digits=digits)
        if username not in seen:
            seen.add(username)
            result.append(username)
    return result


def explain_pattern(samples: list[str]) -> str:
    return 'Твои примеры похожи на CVCVCV: согласная + гласная + согласная + гласная + согласная + гласная.'
