from __future__ import annotations

import hmac
import hashlib
from urllib.parse import urlencode
from .config import Settings


def make_admin_token(settings: Settings, admin_id: int) -> str:
    msg = str(admin_id).encode('utf-8')
    key = settings.admin_web_secret.encode('utf-8')
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def verify_admin_token(settings: Settings, admin_id: int, token: str) -> bool:
    if admin_id not in settings.admin_ids:
        return False
    expected = make_admin_token(settings, admin_id)
    return hmac.compare_digest(expected, token or '')


def make_admin_url(settings: Settings, admin_id: int) -> str:
    query = urlencode({'admin_id': str(admin_id), 'token': make_admin_token(settings, admin_id)})
    return f'{settings.webapp_base_url}/admin?{query}'
