from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

CARD_SIZE = (1600, 900)


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _text_width(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont) -> int:
    box = draw.textbbox((0, 0), text, font=font)
    return box[2] - box[0]


def make_results_card(usernames: list[str], out_path: Path, bot_username: str | None = None) -> Path:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    w, h = CARD_SIZE
    img = Image.new('RGB', CARD_SIZE, (7, 7, 7))
    draw = ImageDraw.Draw(img)

    for y in range(h):
        shade = 7 + int((y / h) * 10)
        draw.line((0, y, w, y), fill=(shade, shade, shade))

    draw.rounded_rectangle((92, 78, 1508, 822), radius=58, fill=(12, 12, 12), outline=(58, 58, 58), width=2)
    draw.rounded_rectangle((124, 110, 1476, 790), radius=42, fill=(18, 18, 18), outline=(42, 42, 42), width=1)

    title_font = _font(72, bold=True)
    item_font = _font(56, bold=True)
    small_font = _font(28, bold=False)
    empty_font = _font(50, bold=True)

    title = 'FOUND USERNAMES'
    draw.text((170, 165), title, font=title_font, fill=(245, 245, 245))
    draw.line((170, 260, 1430, 260), fill=(64, 64, 64), width=2)

    clean = [u.strip().replace('@', '') for u in usernames if u.strip()]
    if not clean:
        message = 'No usernames found'
        draw.text((170, 425), message, font=empty_font, fill=(232, 232, 232))
    else:
        cols = 2 if len(clean) > 5 else 1
        x_positions = [170, 825]
        y_start = 330
        step = 76
        max_items = 14
        split = min(7, (min(len(clean), max_items) + 1) // 2) if cols == 2 else max_items
        for i, username in enumerate(clean[:max_items]):
            col = 1 if cols == 2 and i >= split else 0
            row = i - split if col == 1 else i
            x = x_positions[col]
            y = y_start + row * step
            box = (x, y - 13, x + 555, y + 58)
            draw.rounded_rectangle(box, radius=22, fill=(25, 25, 25), outline=(55, 55, 55), width=1)
            draw.text((x + 26, y - 3), '@' + username, font=item_font, fill=(248, 248, 248))

    footer = 'Telegram Username Finder'
    if bot_username:
        footer += f' · @{bot_username.replace("@", "")}'
    footer_w = _text_width(draw, footer, small_font)
    draw.text(((w - footer_w) // 2, 735), footer, font=small_font, fill=(150, 150, 150))

    img.save(out_path, 'PNG', optimize=True)
    return out_path
