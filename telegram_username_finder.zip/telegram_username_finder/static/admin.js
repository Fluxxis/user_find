const ADMIN_ID = window.ADMIN_ID;
const ADMIN_TOKEN = window.ADMIN_TOKEN;
let lastCode = '';

// Loader management.  We track nested calls and only hide the loader when
// all asynchronous operations have completed.  The global loader is
// defined in admin.html and styled in admin.css.
let _loaderCount = 0;

function showLoader() {
  _loaderCount++;
  const loader = document.getElementById('global-loader');
  if (loader) loader.classList.remove('hidden');
}

function hideLoader() {
  _loaderCount = Math.max(0, _loaderCount - 1);
  if (_loaderCount === 0) {
    const loader = document.getElementById('global-loader');
    if (loader) loader.classList.add('hidden');
  }
}

function headers() {
  return {
    'X-Admin-Id': ADMIN_ID,
    'X-Admin-Token': ADMIN_TOKEN,
  };
}

function toast(message, type = 'error') {
  const root = document.getElementById('toast-root');
  const item = document.createElement('div');
  item.className = `toast ${type}`;
  item.textContent = message;
  root.appendChild(item);
  setTimeout(() => {
    item.style.opacity = '0';
    item.style.transform = 'translateY(-10px) scale(.98)';
    setTimeout(() => item.remove(), 220);
  }, 3600);
}

async function apiGet(url) {
  showLoader();
  try {
    const res = await fetch(url, { headers: headers() });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.detail || data.error || await res.text());
    return data;
  } finally {
    hideLoader();
  }
}

async function apiPost(url, form) {
  showLoader();
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: headers(),
      body: form,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok && !data.requires_password) throw new Error(data.error || data.detail || 'Ошибка запроса');
    return data;
  } finally {
    hideLoader();
  }
}

function setStep(step) {
  document.querySelectorAll('[data-step]').forEach(el => el.classList.toggle('hidden', el.dataset.step !== step));
  document.querySelectorAll('[data-step-dot]').forEach(el => el.classList.toggle('active', el.dataset.stepDot === step));
}

function syncApiFields(form) {
  const visibleId = form.querySelector('input[name="api_id_visible"]');
  const visibleHash = form.querySelector('input[name="api_hash_visible"]');
  const hiddenId = form.querySelector('input[name="api_id"]');
  const hiddenHash = form.querySelector('input[name="api_hash"]');
  if (visibleId && visibleId.value.trim()) hiddenId.value = visibleId.value.trim();
  if (visibleHash && visibleHash.value.trim()) hiddenHash.value = visibleHash.value.trim();
}

async function loadStatus() {
  const pill = document.getElementById('status-pill');
  const accountLine = document.getElementById('account-line');
  const deleteBtn = document.getElementById('delete-session');
  try {
    const data = await apiGet('/api/admin/status');
    if (data.authorized) {
      const name = data.me?.username ? `@${data.me.username}` : (data.me?.first_name || 'аккаунт');
      pill.textContent = `Подключен ${name}`;
      pill.className = 'connection ok';
      accountLine.textContent = `Рабочая сессия активна. Режим: ${data.session_mode}`;
      // Show delete button when a session is authorized
      if (deleteBtn) deleteBtn.classList.remove('hidden');
    } else {
      pill.textContent = 'Аккаунт не подключен';
      pill.className = 'connection bad';
      accountLine.textContent = data.error || 'Сессия не авторизована.';
      if (deleteBtn) deleteBtn.classList.add('hidden');
    }
  } catch (err) {
    pill.textContent = 'Ошибка статуса';
    pill.className = 'connection bad';
    accountLine.textContent = String(err);
    toast(String(err));
    if (deleteBtn) deleteBtn.classList.add('hidden');
  }
}

async function loadStats() {
  const box = document.getElementById('stats-box');
  try {
    const data = await apiGet('/api/admin/stats');
    box.innerHTML = `
      <div><b>${data.checks}</b><span>checks</span></div>
      <div><b>${data.found}</b><span>found</span></div>
      <div><b>${data.runs}</b><span>runs</span></div>
      <div><b>${data.checks_today}</b><span>today</span></div>
    `;
  } catch (err) {
    toast(String(err));
  }
}

async function preview() {
  const length = document.getElementById('preview-length').value;
  const digits = document.getElementById('preview-digits').value;
  const list = document.getElementById('preview-list');
  list.innerHTML = '<span>loading</span>';
  try {
    const data = await apiGet(`/api/admin/generator/preview?length=${length}&digits=${digits}&count=24`);
    list.innerHTML = data.items.map(x => `<span>@${x}</span>`).join('');
  } catch (err) {
    list.innerHTML = '';
    toast(String(err));
  }
}

document.getElementById('refresh-status').addEventListener('click', async () => {
  await loadStatus();
  await loadStats();
  toast('Статус обновлен', 'success');
});

document.getElementById('preview-btn').addEventListener('click', preview);

document.getElementById('manual-login-open').addEventListener('click', () => {
  document.getElementById('login-wizard').classList.remove('hidden');
  setStep('phone');
});

document.getElementById('show-api-fields').addEventListener('click', () => {
  document.getElementById('api-fields').classList.toggle('hidden');
});

document.getElementById('login-start').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  syncApiFields(form);
  try {
    const data = await apiPost('/api/admin/login/start', new FormData(form));
    if (!data.ok) {
      toast(data.error || 'Не удалось отправить код');
      setStep(data.step || 'phone');
      return;
    }
    toast('Код отправлен', 'success');
    setStep('code');
  } catch (err) {
    toast(String(err));
  }
});

document.getElementById('login-complete').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const dataForm = new FormData(form);
  lastCode = String(dataForm.get('code') || '').trim();
  try {
    const data = await apiPost('/api/admin/login/complete', dataForm);
    if (data.requires_password) {
      document.querySelector('#login-password input[name="code"]').value = lastCode;
      toast('Нужен 2FA пароль');
      setStep('password');
      return;
    }
    if (!data.ok) {
      toast(data.error || 'Ошибка входа');
      setStep(data.step || 'code');
      return;
    }
    toast('Аккаунт подключен', 'success');
    await loadStatus();
  } catch (err) {
    toast(String(err));
  }
});

document.getElementById('login-password').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  if (!form.get('code')) form.set('code', lastCode);
  try {
    const data = await apiPost('/api/admin/login/complete', form);
    if (!data.ok) {
      toast(data.error || 'Ошибка 2FA');
      setStep(data.step || 'password');
      return;
    }
    toast('Аккаунт подключен', 'success');
    setStep('phone');
    await loadStatus();
  } catch (err) {
    toast(String(err));
  }
});

document.getElementById('import-session').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const data = await apiPost('/api/admin/session/import', new FormData(e.target));
    if (!data.ok) {
      toast(data.error || 'Session не авторизована');
      return;
    }
    toast('Session импортирована', 'success');
    await loadStatus();
  } catch (err) {
    toast(String(err));
  }
});

// --------------------------------------------------------------------------
// Ban management and session deletion

async function loadBans() {
  const list = document.getElementById('bans-list');
  if (!list) return;
  list.innerHTML = '';
  try {
    const data = await apiGet('/api/admin/bans');
    const banned = data.banned || [];
    if (banned.length === 0) {
      const empty = document.createElement('p');
      empty.textContent = 'Пусто';
      empty.style.color = 'var(--muted)';
      empty.style.fontSize = '14px';
      list.appendChild(empty);
      return;
    }
    banned.forEach((id) => {
      const item = document.createElement('div');
      item.className = 'ban-item';
      const span = document.createElement('span');
      span.textContent = id;
      const btn = document.createElement('button');
      btn.className = 'small danger';
      btn.textContent = '✕';
      btn.addEventListener('click', async () => {
        try {
          const f = new FormData();
          f.append('user_id', id);
          const resp = await apiPost('/api/admin/ban/remove', f);
          if (!resp.ok) toast(resp.error || 'Ошибка удаления');
          else toast('Пользователь разблокирован', 'success');
        } catch (err) {
          toast(String(err));
        }
        loadBans();
      });
      item.appendChild(span);
      item.appendChild(btn);
      list.appendChild(item);
    });
  } catch (err) {
    toast(String(err));
  }
}

document.getElementById('ban-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const fd = new FormData(form);
  const userId = fd.get('user_id');
  if (!userId) return;
  try {
    const resp = await apiPost('/api/admin/ban/add', fd);
    if (!resp.ok) {
      toast(resp.error || 'Ошибка бана');
    } else {
      toast('Пользователь забанен', 'success');
      form.reset();
      loadBans();
    }
  } catch (err) {
    toast(String(err));
  }
});

document.getElementById('refresh-bans')?.addEventListener('click', loadBans);

document.getElementById('delete-session')?.addEventListener('click', async () => {
  if (!confirm('Удалить привязанный аккаунт?')) return;
  try {
    const fd = new FormData();
    const resp = await apiPost('/api/admin/session/delete', fd);
    if (!resp.ok) {
      toast(resp.error || 'Ошибка удаления');
    } else {
      toast('Аккаунт удалён', 'success');
      await loadStatus();
    }
  } catch (err) {
    toast(String(err));
  }
});

loadStatus();
loadStats();
preview();
loadBans();
