# Telegram Username Finder Bot

Бот ищет свободные Telegram usernames по читаемым шаблонам вроде `sayuci`, `tucupo`, `zuduzi`, `goyize`, `wigijo`.

## Что есть

- Генератор нормальных юзов, а не мусорного рандома.
- Режимы 5 и 6 символов.
- Режим только буквы.
- Режим буквы + цифры.
- Проверка через Telethon-аккаунт.
- StringSession вместо рабочей `.session` SQLite базы.
- Меньше конфликтов `database is locked` между ботом и WebApp.
- SQLite WAL, busy timeout и retry на запись.
- Черно-белый округленный Admin WebApp.
- Ручная авторизация по шагам: номер, код, 2FA пароль.
- Верхние уведомления об ошибках: неверный номер, ошибка кода, 2FA, API, session.
- Импорт `.session` файла с конвертацией в StringSession.
- 16:9 PNG-плашки с найденными юзами.
- Плашка без мусора: `FOUND USERNAMES` и подпись `Telegram Username Finder · @bot`.
- Полный запуск на Ubuntu через `start.sh`.
- Бот, WebApp и Cloudflared запускаются в отдельных tmux-сессиях.

## Главный файл настроек

Главный файл настроек: `config.json`.

Открой его:

```bash
nano config.json
```

Заполни:

```json
{
  "bot_token": "TOKEN_FROM_BOTFATHER",
  "admin_ids": [7225974704],
  "admin_web_secret": "LONG_RANDOM_SECRET",
  "telethon": {
    "api_id": 123456,
    "api_hash": "your_api_hash",
    "string_session_path": "data/telethon/checker.string"
  }
}
```

Номер телефона не хранится в `config.json`. Его вводишь в Admin WebApp при ручной авторизации.

`webapp_base_url` руками менять не надо, если запускаешь через `start.sh`. Скрипт сам получит ссылку Cloudflared и запишет её в `config.json`.

## Запуск на Ubuntu дедике

```bash
apt update
apt install -y unzip
unzip telegram_username_finder_v4.zip
cd telegram_username_finder
nano config.json
bash start.sh
```

`start.sh` делает всё:

1. Ставит python3, venv, pip, curl, ca-certificates, tmux.
2. Ставит cloudflared.
3. Создаёт `.venv`.
4. Ставит зависимости из `requirements.txt`.
5. Запускает WebApp в tmux.
6. Запускает Cloudflared tunnel в tmux.
7. Берёт публичную ссылку `trycloudflare.com`.
8. Записывает её в `config.json`.
9. Запускает бота в tmux.

## tmux-сессии

Бот:

```bash
tmux attach -t username_finder_bot
```

WebApp:

```bash
tmux attach -t username_finder_webapp
```

Cloudflared:

```bash
tmux attach -t username_finder_cloudflared
```

Выйти из tmux без остановки:

```text
Ctrl+B, потом D
```

## Логи

```bash
tail -f logs/bot.log
tail -f logs/webapp.log
tail -f logs/cloudflared.log
```

## Админка

В Telegram напиши боту:

```text
/admin
```

Если твой Telegram ID есть в `admin_ids`, бот даст кнопку Admin WebApp.

## Ручная авторизация Telethon

В Admin WebApp нажми `Ручная авторизация`.

Шаги:

1. Введи номер телефона.
2. Нажми `Отправить код`.
3. Введи код из Telegram.
4. Если на аккаунте есть 2FA, введи пароль.
5. После успешного входа создастся `data/telethon/checker.string`.

Если `api_id` и `api_hash` не заполнены в `config.json`, открой блок `Изменить API данные` прямо в форме.

## Импорт `.session`

Если у тебя уже есть `.session` файл:

1. Открой `/admin`.
2. Загрузи `.session`.
3. Укажи `api_id` и `api_hash` или заранее заполни их в `config.json`.
4. WebApp проверит session и сохранит рабочую StringSession.

## Почему было `database is locked`

Там было два слабых места:

1. Основная SQLite база могла ловить блокировку, когда бот писал проверки, а WebApp читал статистику.
2. Telethon `.session` тоже является SQLite-файлом. Бот и WebApp могли одновременно трогать этот файл.

В этой версии это исправлено:

- основная база работает через WAL, busy timeout и retry;
- Telethon рабочая сессия хранится как StringSession;
- импорт старой `.session` конвертируется в StringSession;
- проверка usernames идет через один cached client внутри процесса бота.

## Важно

Проверка свободных username не дает вечную гарантию. Username свободен только в момент проверки.

Не ставь `checker.delay_seconds` в 0. Это слабая идея. Telegram быстро даст FloodWait, и аккаунт перестанет нормально проверять юзы.
