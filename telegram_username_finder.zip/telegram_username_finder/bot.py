from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import CommandStart, Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo, FSInputFile

from app.config import get_settings
from app.auth import make_admin_url
from app.generator import generate_usernames
from app.card import make_results_card
from app.telethon_checker import check_until_found, get_status
from app import db
from app.db import is_user_banned

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(name)s | %(message)s')
logger = logging.getLogger('username_finder_bot')
settings = get_settings()
router = Router()


def is_admin(user_id: int) -> bool:
    return user_id in settings.admin_ids


def main_keyboard(user_id: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text='🔎 5 букв', callback_data='find:5:0'),
            InlineKeyboardButton(text='🔎 6 букв', callback_data='find:6:0'),
        ],
        [
            InlineKeyboardButton(text='🔢 5 + цифры', callback_data='find:5:1'),
            InlineKeyboardButton(text='🔢 6 + цифры', callback_data='find:6:1'),
        ],
        [InlineKeyboardButton(text='📌 Последние находки', callback_data='recent')],
    ]
    if is_admin(user_id):
        rows.append([InlineKeyboardButton(text='⚙️ Admin WebApp', web_app=WebAppInfo(url=make_admin_url(settings, user_id)))])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def safe_edit(message: Message, text: str, reply_markup: InlineKeyboardMarkup | None = None) -> None:
    try:
        await message.edit_text(text, reply_markup=reply_markup)
    except TelegramBadRequest as e:
        if 'message is not modified' not in str(e):
            raise


@router.message(CommandStart())
async def start(message: Message) -> None:
    text = (
        '<b>Username Finder</b>\n\n'
        'Ищет свободные Telegram usernames по читаемым шаблонам.\n'
        'Пример стиля: <code>@sayuci</code>, <code>@tucupo</code>, <code>@zuduzi</code>.\n\n'
        'Выбери режим.'
    )
    await message.answer(text, reply_markup=main_keyboard(message.from_user.id))


@router.message(Command('admin'))
async def admin(message: Message) -> None:
    if not is_admin(message.from_user.id):
        await message.answer('Это действие доступно только администратору.')
        return
    await message.answer(
        'Открой админку. Там подключается Telethon-аккаунт и проверяется статус.',
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text='⚙️ Открыть Admin WebApp', web_app=WebAppInfo(url=make_admin_url(settings, message.from_user.id)))
        ]]),
    )


@router.callback_query(F.data == 'recent')
async def recent(callback: CallbackQuery) -> None:
    await callback.answer()
    items = db.get_recent_found(settings.database_path, limit=20)
    if not items:
        await callback.message.answer('Пока нет сохранённых свободных юзов.')
        return
    text = '<b>Последние находки</b>\n\n' + '\n'.join(f'@{u}' for u in items)
    await callback.message.answer(text, reply_markup=main_keyboard(callback.from_user.id))


@router.callback_query(F.data.startswith('find:'))
async def find_usernames(callback: CallbackQuery) -> None:
    # Immediately acknowledge the callback to prevent client UI from spinning
    await callback.answer('Поиск запущен')

    # Parse length and digits parameters from callback data
    _, length_raw, digits_raw = callback.data.split(':')
    length = int(length_raw)
    digits = digits_raw == '1'

    # If the user is banned, simulate a search without performing real checks
    if is_user_banned(settings.database_path, callback.from_user.id):
        # Inform admin logs that a banned user attempted a search
        # We still log the run but with zero checked and zero found
        target_count = settings.target_found_count
        # Display progress messages similar to a real search
        progress_msg = await callback.message.answer(
            f'⏳ Генерирую кандидаты. Длина: {length}. Режим: {"буквы + цифры" if digits else "только буквы"}.'
        )
        # Simulate delay for generating candidates
        await asyncio.sleep(1.5)
        await safe_edit(progress_msg, f'🔍 Проверяю до {settings.max_checks_per_request} кандидатов. Пауза между проверками: {settings.check_delay_seconds} сек.')
        await asyncio.sleep(2.5)
        # Log a fake search run for banned users
        db.log_search_run(
            settings.database_path,
            user_id=callback.from_user.id,
            target_count=target_count,
            generated_count=0,
            checked_count=0,
            found_count=0,
            length=length,
            digits=digits,
        )
        await progress_msg.delete()
        # Send final message with no results and indicate fake search duration
        caption = (
            f'<b>Готово</b>\n'
            f'Проверено: <b>0</b>\n'
            f'Найдено свободных: <b>0</b>\n'
            f'Время: <b>4 сек.</b>\n\n'
            'Свободных юзов в этом заходе нет. Запусти ещё раз или поменяй режим.'
        )
        await callback.message.answer(
            caption,
            reply_markup=main_keyboard(callback.from_user.id),
        )
        return

    # Normal behaviour for non-banned users
    target_count = settings.target_found_count

    status = await get_status(settings)
    if not status.get('authorized'):
        reason = status.get('error') or 'сессия не авторизована'
        await callback.message.answer(
            f'Telethon-аккаунт не подключён. Открой /admin и добавь аккаунт. Причина: {reason}',
            reply_markup=main_keyboard(callback.from_user.id),
        )
        return

    # Show initial progress
    progress = await callback.message.answer(
        f'⏳ Генерирую кандидаты. Длина: {length}. Режим: {"буквы + цифры" if digits else "только буквы"}.'
    )
    # Generate candidates locally
    candidates = generate_usernames(length=length, digits=digits, count=settings.max_checks_per_request)
    await safe_edit(progress, f'🔍 Проверяю до {settings.max_checks_per_request} кандидатов. Пауза между проверками: {settings.check_delay_seconds} сек.')

    # Perform checks via Telethon until enough found or limit reached
    started_at = time.time()
    found, checked, flood_wait = await check_until_found(settings, candidates, target_count=target_count)
    found_names = [item.username for item in found]
    db.log_search_run(
        settings.database_path,
        user_id=callback.from_user.id,
        target_count=target_count,
        generated_count=len(candidates),
        checked_count=len(checked),
        found_count=len(found_names),
        length=length,
        digits=digits,
    )

    elapsed = int(time.time() - started_at)
    card_path = Path('data/cards') / f'{callback.from_user.id}_{int(time.time())}.png'
    bot_me = await callback.bot.get_me()
    make_results_card(found_names, card_path, bot_username=bot_me.username)

    caption = (
        f'<b>Готово</b>\n'
        f'Проверено: <b>{len(checked)}</b>\n'
        f'Найдено свободных: <b>{len(found_names)}</b>\n'
        f'Время: <b>{elapsed} сек.</b>\n'
    )
    if flood_wait:
        caption += f'\nTelegram временно ограничил проверки: <b>{flood_wait} сек.</b>'
    if found_names:
        caption += '\n\n' + '\n'.join(f'@{name}' for name in found_names)
    else:
        caption += '\nСвободных юзов в этом заходе нет. Запусти ещё раз или поменяй режим.'

    await progress.delete()
    await callback.message.answer_photo(
        photo=FSInputFile(card_path),
        caption=caption,
        reply_markup=main_keyboard(callback.from_user.id),
    )


async def main() -> None:
    db.init_db(settings.database_path)
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    await dp.start_polling(bot)


if __name__ == '__main__':
    asyncio.run(main())
